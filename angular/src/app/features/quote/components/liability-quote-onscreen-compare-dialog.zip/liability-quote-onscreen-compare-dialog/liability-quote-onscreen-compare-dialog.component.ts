import { Component, OnInit } from '@angular/core';
import { MenuItem, MessageService } from 'primeng/api';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { IOneResponseDto } from 'src/app/app.model';
import { AllowedProductTemplate, IProduct } from 'src/app/features/admin/product/product.model';
import { ICGLTemplate } from 'src/app/features/admin/quote/quote.model';
import { QuoteService } from 'src/app/features/admin/quote/quote.service';

@Component({
  selector: 'app-liability-quote-onscreen-compare-dialog',
  templateUrl: './liability-quote-onscreen-compare-dialog.component.html',
  styleUrls: ['./liability-quote-onscreen-compare-dialog.component.scss']
})
export class LiabilityQuoteOnscreenCompareDialogComponent implements OnInit {
  quote: any;
  optionLists: any[];
  questionAnswerListToBind: any[] = [];
  product: IProduct;
  optionOneTemplate: ICGLTemplate;
  selectedOptionForCompare: ICGLTemplate;
  isDandOProduct: boolean
  isCGLProduct: boolean
  isEandOOProduct: boolean
  isWCProdduct: boolean;
  isPublicProduct: boolean;
  isCyberProduct: boolean;
  isCrimeProduct: boolean;
  selectedDropdown: any;
  optionsQuoteOptions: any;
  tabs: MenuItem[] = [];
  mapping: any[] = [];
  tabName: string;
  constructor(public config: DynamicDialogConfig, public ref: DynamicDialogRef, private quoteService: QuoteService, private messageService: MessageService) {
    this.quote = this.config.data.quote;
    this.product = this.quote.productId;
    this.product.productTemplate == AllowedProductTemplate.LIABILITY ? this.isDandOProduct = true : this.isDandOProduct = false
    this.product.productTemplate == AllowedProductTemplate.LIABILITY_CGL ? this.isCGLProduct = true : this.isCGLProduct = false
    this.product.productTemplate == AllowedProductTemplate.LIABILITY_CRIME ? this.isCrimeProduct = true : this.isCrimeProduct = false
    this.product.productTemplate == AllowedProductTemplate.LIABILITY_CYBER ? this.isCyberProduct = true : this.isCyberProduct = false
    this.product.productTemplate == AllowedProductTemplate.LIABILITY_EANDO ? this.isEandOOProduct = true : this.isEandOOProduct = false
    this.product.productTemplate == AllowedProductTemplate.LIABILITY_PUBLIC ? this.isPublicProduct = true : this.isPublicProduct = false
    this.product.productTemplate == AllowedProductTemplate.WORKMENSCOMPENSATION ? this.isWCProdduct = true : this.isWCProdduct = false
  }

  handleQuoteOptionChangeLiability(event: any) {

  }

  ngOnInit(): void {
    this.quoteService.getAllLiabilityQuoteOptions(this.quote._id).subscribe({
      next: (dto: IOneResponseDto<any[]>) => {
        this.optionsQuoteOptions = dto.data.entity.filter(x => x.version == this.quote.qcrVersion).map(entity => ({ label: entity.optionName, value: entity._id })); // Set the Id to this component
        this.optionLists = dto.data.entity.filter(x => x.version == this.quote.qcrVersion)
        if (this.optionLists.length >= 2) {
          this.optionOneTemplate = this.optionLists[0];
          this.selectedOptionForCompare = this.optionLists[1];
          this.selectedDropdown = this.optionLists[1]._id;
        } else {
          console.warn('Insufficient options for comparison');
          this.optionOneTemplate = this.optionLists[0] || null;
          this.selectedOptionForCompare = null;
          this.selectedDropdown = null;
        }
        this.tabs = this.loadTabs(this.product)
        this.tabs.forEach(tab => {
          this.tabName = tab.label
          this.selectTab(tab)
        });
      },
      error: error => {
        console.log(error);
      }
    });
  }




  loadTabs(product: IProduct): MenuItem[] {
    switch (product.productTemplate) {
      case AllowedProductTemplate.LIABILITY_CGL:
        return [
          { label: "Basic Details", id: "basic_details" },
          { label: "Territory & Subsidiary Details", id: "territorysubsidiary" },
          { label: "Claim Experience & Turnover Details", id: "revenue_details" }
        ]
      default:
        return [
          { label: "Basic Details", id: "basic_details" },
          { label: "Territory & Subsidiary Details", id: "territorysubsidiary" },
          { label: "Breakup Details", id: 'revenue_details' },
          { label: "Deductibles & Claim Experience", id: 'deductibles' },
          { label: "Other Details", id: "other_details" },
        ]
    }
  }

  selectTab(tab?: MenuItem) {
    if (!tab || !this.optionOneTemplate || !this.selectedOptionForCompare) {
      console.warn('Tab, optionOneTemplate, or selectedOptionForCompare is undefined.');
      return;
    }
    switch (tab.id) {
      case 'basic_details':
        this.mapping.push({
          labels: { type: 'string', value: "Additional Information" },
          [this.optionOneTemplate._id]: {
            type: 'string',
            value: this.optionOneTemplate.additionalInformation || 'N/A'
          },
          [this.selectedOptionForCompare._id]: {
            type: 'string',
            value: this.selectedOptionForCompare.additionalInformation || 'N/A',
            style: this.selectedOptionForCompare.additionalInformation !== this.optionOneTemplate.additionalInformation ? { color: 'red' } : null,
          },
        });
        break;

      case 'territorysubsidiary':
        this.mapping.push({
          labels: { type: 'string', value: "Jurisdiction" },
          [this.optionOneTemplate._id]: {
            type: 'string',
            value: this.optionOneTemplate.juridictionId['lovKey'] || 'N/A'
          },
          [this.selectedOptionForCompare._id]: {
            type: 'string',
            value: this.selectedOptionForCompare.juridictionId['lovKey'] || 'N/A',
            style: this.selectedOptionForCompare.juridictionId['lovKey'] !== this.optionOneTemplate.juridictionId['lovKey'] ? { color: 'red' } : null,
          },
        });
        break;

      case 'revenue_details':
        this.mapping.push({
          labels: { type: 'string', value: "Territory" },
          [this.optionOneTemplate._id]: {
            type: 'string',
            value: this.optionOneTemplate.territoryId['lovKey'] || 'N/A'  // Changed to match Option 2
          },
          [this.selectedOptionForCompare._id]: {
            type: 'string',
            value: this.selectedOptionForCompare.territoryId['lovKey'] || 'N/A',
            style: this.selectedOptionForCompare.territoryId['lovKey'] !== this.optionOneTemplate.territoryId['lovKey'] ? { color: 'red' } : null,
          },
        });
        break;
    }
  }


}
